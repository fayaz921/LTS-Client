import axios from "axios"
import type { CreateCaseDto } from "../types/case.types";

const createCase = async (data: CreateCaseDto) => {
    try {
        const response = await axios.post('/Case/create', data);
        return response.data;
    } catch (error) {
        console.error('Error creating case:', error);
        throw error;
    }
}

const getCases = async () => {
    try {
        const response = await axios.get('/Case/getAll');
        return response.data;
    } catch (error) {
        console.error('Error fetching cases:', error);
        throw error;
    }
}

export default {
    createCase,
    getCases
}