import axiosInstance from '../../../lib/axios';
import type {
  CreateUserCommand, LoginUserCommand,
  VerifyOtpCommand, ForgetPasswordCommand,
  VerifyEmailCommand, ApiResponse
} from '../types/auth.types';

export const SignUpUser = async (command: CreateUserCommand): Promise<ApiResponse<string>> => {
  const response = await axiosInstance.post('/Auth/SignIn', command);
  return response.data;
};

export const loginUser = async (command: LoginUserCommand): Promise<ApiResponse<string>> => {
  const response = await axiosInstance.post('/Auth/Login', command);
  return response.data;
};

export const confirmOtp = async (command: VerifyOtpCommand): Promise<ApiResponse<string>> => {
  const response = await axiosInstance.post('/Auth/ConfirmOtp', command);
  return response.data;
};

export const forgetPassword = async (command: ForgetPasswordCommand): Promise<ApiResponse<string>> => {
  const response = await axiosInstance.post('/Auth/ForgetPassword', command);
  return response.data;
};

export const verifyEmail = async (command: VerifyEmailCommand): Promise<ApiResponse<string>> => {
  const response = await axiosInstance.post('/Auth/VerifyEmail', command);
  return response.data;
};